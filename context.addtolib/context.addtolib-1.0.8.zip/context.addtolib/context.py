﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#     Copyright (C) 2016 Taifxx
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
########## CONTEXT MENUE ACTIONS:

##### Import local modules ...
import resources.lib.help as help

from resources.lib.common  import *
from resources.lib.menues  import *
from resources.lib.call    import *

##### Compability addon vars ...
__addon__        = addon.addon 
__addonprofile__ = addon.profile
__addonname__    = addon.name
__localize__     = addon.localize
__addonid__      = addon.id
__author__       = addon.author
__version__      = addon.version
__addonpath__    = addon.path
__icon__         = addon.icon
__language__     = addon.localize


##### Call ...
def Main():

    #help.dlgHelp()
    #s = GUI.dlgSel(['Item1', 'Item2', 'Item3'], title='TEST')
    #s = GUI.dlgSelXSub('msg','X CAP', ['Item1', 'Item2', 'Item3']).position
    
    #s = DOS.exists(DOS.join(addon.profile, TAG_PAR_LOCKF))
    
    #GUI.dlgOk(DOS.join(addon.profile, TAG_PAR_LOCKF).replace('AppData\\Roaming','')+' : '+str( s ))
    
    #GUI.dlgOk('TESR')

    #GUI.messageX('Text','Caption')
    #GUI.tt('Text','Caption')
    #GUI.dlgOk('>>')
    #GUI.dlgYn('>>')

    #return

    arg = parseArgs()
    if   arg == TAG_CND_NOACTION : plgMain()
    elif arg != TAG_CND_PLAY     : plgMain(arg)

##### Main ...
class plgMain(GUI.CAltDTmpl):        
    
    def _cleanObject(self, obj):
        try    : del obj 
        except : pass
        
    
    def updlock(self, action=Empty, lock=False, check=False):
        filepath = DOS.join(addon.profile, TAG_PAR_LOCKF)
        isex     = lambda : DOS.exists(filepath) 
    
        if not check:
            if lock : DOS.file(TAG_PAR_LOCKF, addon.profile, str(0))    
            else    : DOS.delf(filepath)
            
        elif isex():
            if not action:
                calln = inte(DOS.file(TAG_PAR_LOCKF, addon.profile, fType=FRead))
                
                if calln < 2:
                    DOS.file(TAG_PAR_LOCKF, addon.profile, str(calln+1), fRew=True) 
                    errord(TAG_ERR_LOCK, Empty); return False
                else: 
                    if not confirm (TAG_CFR_UNLOCK) : return False
                    DOS.delf(filepath) 
        
        return True
    
    def started(self, iss, action=Empty):
        if action : file = TAG_PAR_STRARTAF
        else      : file = TAG_PAR_STRARTF
         
        if iss : DOS.file(file, addon.profile, Empty)
        else   : DOS.delf(DOS.join(addon.profile, file))
        
    
    def check_exilib(self, action):
        
        if not DOS.exists(LIB.lib): 
            
            if not action:
                errord(TAG_ERR_LIB, Empty)
                self.mnu_set()
                return False
                
            elif action != TAG_ACT_LPRESET:
                errord(TAG_ERR_LIBACT, Empty)
                return False
                
        return True


    def setTVS(self, path, isFound):
        self._cleanObject(self.TVS)
        self.path    = path 
        self.isFound = isFound
        self.TVS = CTVS.TVS(TAG_PAR_TVSPACK_FILE, path, isFound)
        self.setSRC()
    
    
    def setLI(self, dirPath=Empty, srcName=Empty):
        self._cleanObject(self.items)
        self.items = LI.vidItems(dirPath, srcName)
     
        
    def setLinkTable(self):
        self._cleanObject(self.linkTable)
        self.linkTable = CTVS.CLinkTable(TAG_PAR_STL_FILE, LIB.lib)
    
    
    def setSRC(self):
        self._cleanObject(self.src)
        self.src = CSRC(*self.TVS.get_names_and_links())
    
    
    def setFile(self, rep=False):
        self.isFound, self.container, self.path, isOL = checkfile(self.items, self.linkTable)
        if rep and isOL : errord(TAG_ERR_OL, Empty) 
    
    
    def libClean(self, always=False):
        if addon.UPDAFTER or always: 
            if GUI.dlgYn (tl(TAG_CFR_CLEANVL)) : GUI.libClean()
    
    
    def libUpdate(self, report=False, always=False):
        if addon.UPDAFTER or always: 
            GUI.libUpdate()
            if self.container in [TAG_CON_VID, TAG_CON_LOCAL]: GUI.refresh()
            if report : errord(TAG_ERR_OK, TAG_ERR_OK_VIDLIBU)
    
    
    def back(self):
        GUI.back()
     
        
    def doAction(self, action=Empty):
        ## Redefine values ... 
        self.setSRC() 
        self.isNewSource    = self.src.isnewsrc(self.items.vidCPath)
        self.isNewFolSource = self.src.isnewfrc(self.items.vidCPath)
    
        ## Delete existing menues ...
        try    : del self.MainMenue, self.tvsmMenue, self.srcmMenue, self.updtMenue 
        except : pass
        
        ## Define Visible conditions ...
        curVisCond         = {self.container,
                              TAG_CND_NOTFOUND  if not self.isFound        else TAG_CND_FOUND,
                              TAG_CND_NEWSRC    if self.isNewSource        else TAG_CND_OLDSRC,
                              TAG_CND_NEWFRC    if self.isNewFolSource     else TAG_CND_OLDFRC,
                              TAG_TYP_FOLDER    if self.items.vidIsFolder  else TAG_TYP_FILE,
                              TAG_CND_LISTEMPTY if self.items.vidIsEmpty   else Empty,
                              TAG_CND_NOUPD     if not addon.ADDUPD        else Empty,
                              TAG_CND_UPDPRC    if isGlUpProcess()         else TAG_CND_NOUPDPRC,
                              TAG_CND_NOGL      if isNoGlUp()              else Empty}
        
                              
        ## Define Main Menue ...
        self.MainMenue = tagMenue({'pos':0, 'tag':TAG_MNU_MOV,      'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_TYP_FOLDER}},
                                  {'pos':1, 'tag':TAG_MNU_TVS,      'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_LISTEMPTY, TAG_CND_OLDSRC}},
                                  {'pos':2, 'tag':TAG_MNU_TVSU,     'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_LISTEMPTY, TAG_CND_NEWSRC}},
                                  {'pos':3, 'tag':TAG_MNU_UPDFOL,   'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_NEWFRC}},
                                  {'pos':4, 'tag':TAG_MNU_CONTUPD,  'hideCond':{TAG_CND_NOUPDPRC}},
                                  {'pos':5, 'tag':TAG_MNU_CHKNEW,   'hideCond':{TAG_CND_NOTFOUND}},
                                  {'pos':6, 'tag':TAG_MNU_OPEN,     'hideCond':{TAG_CND_NOTFOUND}},
                                  {'pos':7, 'tag':TAG_MNU_CHKNEWGL, 'hideCond':{}},
                                  {'pos':8, 'tag':TAG_MNU_CONTUPD,  'hideCond':{TAG_CND_UPDPRC, TAG_CND_NOGL}},
                                  {'pos':9, 'tag':TAG_MNU_RAWADD,   'hideCond':{TAG_CON_LOCAL, TAG_CON_VID}},
                                  {'pos':10,'tag':TAG_MNU_VIDLIBU,  'hideCond':{TAG_CND_NOUPD}},
                                  {'pos':11,'tag':TAG_MNU_VIDLIBCLN,'hideCond':{TAG_CND_NOUPD}},
                                  {'pos':12,'tag':TAG_MNU_SRCMAN,   'hideCond':{(TAG_CON_LOCAL, TAG_CND_NOTFOUND), (TAG_CON_VID, TAG_CND_NOTFOUND)}},
                                  {'pos':13,'tag':TAG_MNU_UPDMAN,   'hideCond':{TAG_CND_NOTFOUND}},
                                  {'pos':14,'tag':TAG_MNU_TVSMAN,   'hideCond':{}},         
                                  {'pos':1, 'tag':TAG_MNU_HELP,     'hideCond':{}, 'refPage':addon.SETPAGE-1},
                                  {'pos':2, 'tag':TAG_MNU_SET,      'hideCond':{}, 'refPage':addon.SETPAGE-1},
                                  pageLimit = addon.MNUITMNUM,
                                  cancelTag = TAG_MNU_CANCEL, 
                                  backTag   = TAG_MNU_BACK, 
                                  nextTag   = TAG_MNU_MORE,
                                  visCond   = curVisCond,
                                  title     = normName(self.TVS.lib_name),
                                  addict    = tla(TAG_TTL_MAINMNU)) 
         
        ## Define Sub Menues ... 
        self.tvsmMenue = tagMenue({'pos':0, 'tag':TAG_MNU_SHOWALL,    'hideCond':{}},
                                  #{'pos':1, 'tag':TAG_MNU_ADVADD,     'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_LISTEMPTY}},  
                                  {'pos':2, 'tag':TAG_MNU_REBSTL,     'hideCond':{}},
                                  {'pos':3, 'tag':TAG_MNU_JOIN,       'hideCond':{}},
                                  {'pos':4, 'tag':TAG_MNU_TVSREN,     'hideCond':{}},
                                  {'pos':5, 'tag':TAG_MNU_DELETE,     'hideCond':{}},
                                  {'pos':6, 'tag':TAG_MNU_RESTORE,    'hideCond':{}},
                                  {'pos':7, 'tag':TAG_MNU_RESTOREALL, 'hideCond':{}},
                                  {'pos':8, 'tag':TAG_MNU_RESCANFULL, 'hideCond':{}},
                                  pageLimit = addon.MNUITMNUM,
                                  cancelTag = TAG_MNU_BACKMAIN, 
                                  backTag   = TAG_MNU_BACK, 
                                  nextTag   = TAG_MNU_MORE,
                                  visCond   = curVisCond,
                                  title     = titName(TAG_MNU_TVSMAN, self.TVS.lib_name),
                                  addict    = tla(TAG_TTL_MAINMNU)+TAG_PAR_LNSEP+tla(TAG_MNU_TVSMAN))
        
        self.srcmMenue = tagMenue({'pos':0, 'tag':TAG_MNU_ADDFOL,    'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_OLDFRC}},
                                  #{'pos':0, 'tag':TAG_MNU_UPDFOL,   'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_NEWFRC}},
                                  {'pos':1, 'tag':TAG_MNU_ADVADD,    'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_LISTEMPTY}},
                                  {'pos':2, 'tag':TAG_MNU_BRWSREN,   'hideCond':{TAG_CND_NOTFOUND}},   
                                  {'pos':3, 'tag':TAG_MNU_REMSRC,    'hideCond':{TAG_CND_NOTFOUND}},
                                  {'pos':4, 'tag':TAG_MNU_RESCAN,    'hideCond':{TAG_CON_LOCAL, TAG_CON_VID, TAG_CND_NOTFOUND, TAG_CND_NEWSRC}},
                                  {'pos':5, 'tag':TAG_MNU_RESCANALLS,'hideCond':{TAG_CND_NOTFOUND}},
                                  {'pos':6, 'tag':TAG_MNU_SRCREN,    'hideCond':{TAG_CND_NOTFOUND}},
                                  pageLimit = addon.MNUITMNUM,
                                  cancelTag = TAG_MNU_BACKMAIN, 
                                  backTag   = TAG_MNU_BACK, 
                                  nextTag   = TAG_MNU_MORE,
                                  visCond   = curVisCond,
                                  title     = titName(TAG_MNU_SRCMAN, self.TVS.lib_name),
                                  addict    = tla(TAG_TTL_MAINMNU)+TAG_PAR_LNSEP+tla(TAG_MNU_SRCMAN))
        
        self.updtMenue = tagMenue({'pos':0, 'tag':TAG_MNU_TVSU,     'hideCond':{}},
                                  {'pos':0, 'tag':TAG_MNU_SHDIR,    'hideCond':{}},  
                                  pageLimit = addon.MNUITMNUM,
                                  cancelTag = TAG_MNU_BACKMAIN, 
                                  backTag   = TAG_MNU_BACK, 
                                  nextTag   = TAG_MNU_MORE,
                                  visCond   = curVisCond,
                                  title     = titName(TAG_TTL_NEWEPS, self.TVS.lib_name),
                                  addict    = tla(TAG_TTL_MAINMNU)+TAG_PAR_LNSEP+tla(TAG_MNU_UPDMAN))
    
        ## Show Main menue ...
        if self.result not in [TAG_MNU_TVS,     TAG_MNU_TVSU,   TAG_MNU_TVSMAN, TAG_MNU_SRCMAN, TAG_MNU_DELETE, 
                               TAG_MNU_RESTORE, TAG_MNU_TVSREN, TAG_MNU_REMSRC, TAG_MNU_SRCREN, TAG_MNU_CHKNEW,
                               TAG_MNU_BRWSREN] and not action:
                                             
                                             self.pageNum,  self.result = self.MainMenue.show(self.pageNum)
        elif action : self.result = action 
                          
        ## Show Sub menues ...   
        if   self.result == TAG_MNU_SRCMAN : self.srcmPage, self.result = self.srcmMenue.show(self.srcmPage)  
        elif self.result == TAG_MNU_TVSMAN : self.tvsmPage, self.result = self.tvsmMenue.show(self.tvsmPage)
        
        if self.updlock(action, check=True) : self.result == TAG_MNU_CANCEL
        
        ## Parse results ...
        if   self.result == TAG_MNU_CANCEL      : pass
        elif self.result == TAG_MNU_ADDFOL      : self.result = self.mnu_addfol()
        elif self.result == TAG_MNU_UPDFOL      : self.result = self.mnu_updfol()
        elif self.result == TAG_MNU_BRWSREN     : self.result = self.mnu_brwsren()
        elif self.result == TAG_MNU_JOIN        : self.result = self.mnu_join()
        elif self.result == TAG_MNU_TVSREN      : self.result = self.mnu_tvsren()
        elif self.result == TAG_MNU_SRCREN      : self.result = self.mnu_scrren()
        elif self.result == TAG_MNU_REMSRC      : self.result = self.mnu_remsrc()
        elif self.result == TAG_MNU_UPDMAN      : self.result = self.mnu_updman()
        elif self.result == TAG_MNU_SHOWALL     : self.result = self.mnu_showall()
        elif self.result == TAG_MNU_CHKNEW      : self.result = self.mnu_chknew()
        elif self.result == TAG_MNU_CHKNEWGL    : self.result = self.mnu_chknewgl()
        elif self.result == TAG_MNU_CONTUPD     : self.result = self.mnu_chknewgl(True)
        elif self.result == TAG_MNU_DELETE      : self.result = self.mnu_delete()
        elif self.result == TAG_MNU_RESTORE     : self.result = self.mnu_restore()
        elif self.result == TAG_MNU_RESTOREALL  : self.result = self.mnu_restoreall()
        elif self.result == TAG_MNU_RESCAN      : self.result = self.mnu_rescan()
        elif self.result == TAG_MNU_REBSTL      : self.result = self.mnu_rebstl()
        elif self.result == TAG_MNU_RAWADD      : self.result = self.mnu_rawadd()
        elif self.result == TAG_MNU_MOV         : self.result = self.mnu_mov()
        elif self.result == TAG_MNU_TVS         : self.result = self.mnu_tvs()
        elif self.result == TAG_MNU_TVSU        : self.result = self.mnu_tvsu()
        elif self.result == TAG_MNU_ADVADD      : self.result = self.mnu_advadd()
        elif self.result == TAG_MNU_OPEN        : self.result = self.mnu_open()
        elif self.result == TAG_MNU_HELP        : self.result = self.mnu_help()
        elif self.result == TAG_MNU_SET         : self.result = self.mnu_set()
        elif self.result == TAG_MNU_VIDLIBU     : self.result = self.mnu_vidlibu()
        elif self.result == TAG_MNU_VIDLIBCLN   : self.result = self.mnu_vidlibcln()
        elif self.result == TAG_MNU_RESCANALLS  : self.result = self.mnu_rescanalls()
        elif self.result == TAG_MNU_RESCANFULL  : self.result = self.mnu_rescanfull()
        elif self.result == TAG_ACT_LPRESET     : self.result = self.act_lpreset()
        elif self.result == TAG_ACT_SHADOWUPD   : self.result = self.act_shadowupd()
        elif self.result == TAG_ACT_DONOTHING   : self.result = self.act_donothing()
        elif self.result == TAG_ACT_CHCOLOR     : self.result = self.act_chcolor()
        elif self.result == TAG_ACT_RENAMER     : self.result = self.act_renamer()
        elif self.result == TAG_ACT_BACKUP      : self.result = self.act_backup()
        elif self.result == TAG_ACT_REMBACK     : self.result = self.act_remback()
        elif self.result == TAG_ACT_RESTBACK    : self.result = self.act_restback()
        elif self.result == TAG_ACT_RESETTBU    : self.result = self.act_resettbu()
        elif self.result == TAG_ACT_AUTOBACKUP  : self.result = self.act_autobackup()
        elif self.result == TAG_ACT_RESKIN      : self.result = self.act_reskin()
    
    
    def __init__(self, action=Empty):
        ## Create Addon Profile folder ...
        DOS.mkdirs(LIB.lib)
        if not self.check_exilib(action)        : return
        if not self.updlock(action, check=True) : return
        self.started(True, action)
        check_lib_folders(False)
        
        CTVS.BGPROCESS = addon.BGUPD
        LI.DETVIDEXT   = addon.DETVIDEXT
    
        ## Define empty objects ...
        self.linkTable = None
        self.items     = None
        self.TVS       = None
        self.src       = None
        
        self.fListUPD  = []
        self.sListUPD  = []
        self.reErrors  = []
            
        ## Set defaults ...
        self.setLI()
        self.setLinkTable()
        self.setFile(True if not action else False)
        self.setTVS(self.path, self.isFound)
        
        self.result   = Empty
        self.pageNum  = 0
        self.tvsmPage = 0
        self.srcmPage = 0
        self.updtPage = 0
        
        ## Start main menue process ...
        while self.result != TAG_MNU_CANCEL : self.doAction(action)
        
        ## Unlock upd ...
        self.updlock(lock=False)
        self.started(False, action)
        
        ## Delete all objects ...
        del self.srcmMenue, self.tvsmMenue, self.updtMenue, self.MainMenue, self.src, self.items, self.TVS, self.linkTable 
    
    
    
    def mnu_addfol(self): 
    
        rd = TAG_MNU_SRCMAN
                                                                     
        tvsNames, tvsPaths = getAllTVS()
        newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), 
                           title=titName(TAG_MNU_ADDFOL, self.TVS.lib_name))
                           
        if not newPath : return rd 
        
        self.setTVS(newPath, True) 
        if not errord(addFolSRC(self.items, self.TVS), TAG_ERR_OK_ADDFOL, normName(self.TVS.lib_name)):
            self.linkTable.add(self.TVS.lib_path, self.items.vidCPath)
                
        return rd
        
        
    def mnu_updfol(self):  
    
        rd = TAG_MNU_CANCEL
                                                                 
        errord(updFolSRC(self.items, self.TVS), TAG_ERR_OK_UPDFOL, normName(self.TVS.lib_name))
        
        return rd
        
        
    def mnu_brwsren(self):
    
        rd = TAG_MNU_BRWSREN
        
        srccl = self.src.clone(nofrc=True)
        
        mdefault = srccl.getlinkidx(self.items.vidCPath)
        srccl(subMenue(srccl.remnames, srccl.idxs, cancelVal=-1, default=mdefault, defidx=0, 
                          title=titName(TAG_MNU_BRWSREN, self.TVS.lib_name)))
                          
        if not srccl.isidx : return TAG_MNU_SRCMAN
        
        while True: 
        
            epsnames, epslinks = self.TVS.get_eps_names_and_links_forsrc(srccl.link)
            
            reslink = subMenue(epsnames, epslinks, cancelVal=Empty, title=tl(TAG_TTL_BRWSREN) % (tla(TAG_MNU_BRWSREN), normName(self.TVS.lib_name), srccl.name))
            
            if not reslink : return rd
            
            oldname = self.TVS.get_eps_name_by_link(reslink)
            newName = GUI.dlgIn(tl(TAG_TTL_BRWSRENEP), oldname)
            
            if oldname != newName:
                prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty          
                errord(renEPS(self.TVS, reslink, newName, oldname, prefix), TAG_ERR_OK_BRWSREN, normName(self.TVS.lib_name)) 
        
        return rd
    
    
    def mnu_rebstl(self):
        
        rd = TAG_MNU_TVSMAN
        
        errord(rebuildLinkTable(), TAG_ERR_OK_REBSTL)
        
        return rd
        
        
    def mnu_join(self):    
    
        rd = TAG_MNU_TVSMAN
                                                              
        tvsNames, tvsPaths = getAllTVS()
        tvsNames2 = [itm for itm in tvsNames]
        tvsPaths2 = [itm for itm in tvsPaths]
        joinPaths = subMenue(tvsNames, tvsPaths, cancelVal=Empty, cancelName=TAG_MNU_OK, multiSel=True, selMarkm=tl(TAG_MNU_SMM), 
                             default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_MNU_JOIN))
        
        if len(joinPaths) < 2 : errord(TAG_ERR_NOTOJOIN, Empty); return rd
        
        if not confirm (TAG_MNU_JOIN) : return rd
        
        tvsNames2.insert(0, tl(TAG_MNU_NEW))
        tvsPaths2.insert(0, TAG_MNU_NEW)            
        mainPaths = subMenue(tvsNames2, tvsPaths2, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), defidx=1, title=titName(TAG_TTL_CHSNAME))
                             
        if    not mainPaths            : return rd 
        elif  mainPaths == TAG_MNU_NEW : newName = GUI.dlgIn(tl(TAG_TTL_ENTNAME))
        else                           : newName = Empty
          
        errn, path, name = joinTVSs(joinPaths, mainPaths, newName, self.linkTable)
        
        if not errord(errn, TAG_ERR_OK_JOIN, normName(name)):  
            self.setTVS(path, True)
            self.libClean()
            self.libUpdate()
                
        return  rd
        
        
    def mnu_tvsren(self): 
    
       rd = TAG_MNU_TVSMAN
                   
       tvsNames, tvsPaths = getAllTVS()
       newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_MNU_TVSREN))
       
       if not newPath : return rd
       
       self.setTVS(newPath, True) 
       oldName = self.TVS.lib_name 
       newName = GUI.dlgIn(tl(TAG_MNU_TVSREN), oldName)
       
       prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
       if not errord(renameTVS(newName, self.TVS, prefix), TAG_ERR_OK_TVSREN, normName(oldName)):
           self.linkTable.chpath(newPath, self.TVS.lib_path)
           self.libClean()
           self.libUpdate() 
           return TAG_MNU_TVSREN 
       
       return rd
       
        
    def mnu_scrren(self):
     
        rd = TAG_MNU_SRCMAN
                                                                     
        mdefault=self.src.getlinkidx(self.items.vidCPath)
        mdefidx=self.src.frclen if mdefault >= self.src.frclen else 0
        self.src(subMenue(self.src.remnames, self.src.idxs, cancelVal=-1, default=mdefault, defidx=mdefidx, 
                          title=titName(TAG_MNU_SRCREN, self.TVS.lib_name)))
                          
        if not self.src.isidx : return rd
          
        oldName = self.src.name 
        newName = GUI.dlgIn(tl(TAG_MNU_SRCREN), oldName)
         
        if not newName : return  rd
        
        if not errord(renameSRC(oldName, newName, self.src.isf, self.TVS), TAG_ERR_OK_SRCREN, normName(self.TVS.lib_name)):
            return  TAG_MNU_SRCREN
        
        return  rd
         
         
    def mnu_remsrc(self):                
    
        rd = TAG_MNU_SRCMAN
                                                  
        mdefault=self.src.getlinkidx(self.items.vidCPath)
        mdefidx=self.src.frclen if mdefault >= self.src.frclen else 0                                                 
        self.src(subMenue(self.src.remnames, self.src.idxs, cancelVal=-1, default=mdefault, defidx=mdefidx,
                          title=titName(TAG_MNU_REMSRC, self.TVS.lib_name)))
                           
        if not self.src.isidx : return rd
         
        if not confirm(TAG_MNU_REMSRC, normName(self.TVS.lib_name), self.src.name) : return rd
        
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
        if not errord(removeSRC(self.src.link, self.src.isf, self.TVS, prefix), TAG_ERR_OK_REMSRC, normName(self.TVS.lib_name)):
           self.linkTable.remove(self.src.link) 
           self.libUpdate()
        
        return rd
         
        
    def mnu_updman(self):                  
    
        rd = TAG_MNU_BACKMAIN
                                                
        srcDef, frcDef = self.TVS.get_upd()
        mdefault=self.src.getlinkidx(self.items.vidCPath)
        mdefidx=self.src.frclen if mdefault >= self.src.frclen else 0
        self.src(subMenue(self.src.remnames, self.src.idxs, cancelVal=-1, cancelName=TAG_MNU_OK, multiSel=True, default=mdefault, selMarkm=tl(TAG_MNU_SM),
                     multiSelDefList=self.src.getidxs(frcDef+srcDef), defidx=mdefidx, title=titName(TAG_MNU_UPDMAN, self.TVS.lib_name)))
                        
        errord(setupdSRC(self.src.fnames, self.src.snames, self.TVS), TAG_ERR_OK_SETUPD, normName(self.TVS.lib_name))                                      
        
        return rd  
        
        
    def mnu_showall(self):
    
        rd = TAG_MNU_TVSMAN
                                                                  
        tvsNames, tvsPaths = getAllTVS()
        
        if not tvsNames : return rd
         
        newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_TTL_EXITVS))
        
        if not newPath  : return rd
         
        self.setTVS(newPath, True)
        self.pageNum = 0
        
        return Empty 
        
        
    def mnu_chknew(self, globalupd=False, silent=False, shadsl=False):
        self.updlock(lock=True)  
        if addon.AUTOUPDSRC and addon.SILENTUPD and not globalupd:
            while True:
                result = self._mnu_chknew()
                if result != TAG_MNU_CHKNEW : return result
        
        else : return self._mnu_chknew(exsilent=silent, exshadu=True if globalupd and addon.AUTOUPDALL else shadsl, shadow=shadsl)  
        
        
    def _mnu_chknew(self, exsilent=False, exshadu=False, shadow=False):                                         
    
        rd = TAG_MNU_CANCEL
        
        self.chkfull = False
        updnow(False)
        
        try    : self.usrc
        except : self.usrc = CSRC(*self.TVS.check_new_eps(titName(TAG_TTL_CHKUPD, self.TVS.lib_name)))
              
        if not self.usrc.idxs : errord(TAG_ERR_OK, TAG_ERR_OK_CHKNEW, normName(self.TVS.lib_name)); del self.usrc; return rd
        
        remnames = [itm for itm in self.usrc.remnames]
        idxs     = [itm for itm in self.usrc.idxs]
        
        nosilent = True if not exsilent and not self.usrc.srccount() else False
        allowmnu = True if not addon.AUTOUPDSRC and not exshadu else False  
        if allowmnu or nosilent or not addon.SILENTUPD: 
        
            mdefault=self.usrc.getlinkidx(self.items.vidCPath) 
            mdefidx=self.usrc.frclen if mdefault >= self.src.frclen else 0
            self.usrc(subMenue(remnames, idxs, cancelVal=-1, default=mdefault, 
                               defidx=mdefidx, title=titName(TAG_TTL_NEWEPS, self.TVS.lib_name)))
                            
            #if not self.usrc.isidx : del self.usrc; return TAG_MNU_BACKMAIN
            if not self.usrc.isidx : del self.usrc; return rd
        
        else: 
            if not self.usrc.nextsidx():
                del self.usrc 
                return rd 
        
        if not addon.SILENTUPD:
        
            oldCont = self.items.vidCPath
            GUI.goTarget(self.usrc.link)
        
            if oldCont != self.usrc.link and not isWait(oldCont, LI.getCpath, addon.LNKTIMEOUT) : errord(TAG_ERR_DEDLINK); return TAG_MNU_CHKNEW 
        
            self.setLI()
         
            if self.usrc.isf : updnow(True); return rd 
            else             :
                self.TVS.os_getraw()
                if self.usrc.link not in self.TVS.get_raw_link_list() : self.mnu_tvsu  (False)
                else                                                  : self.mnu_rawadd(True)
        
            self.back()
            
        else: 
            
            self.setLI(self.usrc.link, self.usrc.name)
            if self.usrc.isf:
                oldCont = self.items.vidCPath 
                GUI.goTarget(self.usrc.link)
                if oldCont != self.usrc.link and not isWait(oldCont, LI.getCpath, addon.LNKTIMEOUT) : errord(TAG_ERR_DEDLINK); return TAG_MNU_CHKNEW
                updnow(True)
                return rd
                
            self.TVS.os_getraw()
            if self.usrc.link not in self.TVS.get_raw_link_list() : self.mnu_tvsu  (False)
            elif not (addon.NOREPRAWAUTO and shadow)              : self.mnu_rawadd(True)
        
        self.setLI()
             
        self.usrc.exclude(self.usrc.link)
        self.libUpdate()
    
        if self.usrc.idxs : return TAG_MNU_CHKNEW       
        
        del self.usrc
        
        self.chkfull = True
        
        return rd 
    
    
    def act_shadowupd(self):
        if DOS.exists(DOS.join(addon.profile, TAG_PAR_STRARTF)) : return TAG_MNU_CANCEL 
        self.updlock(lock=True)
        self.mnu_chknewgl(shadow=addon.NOREPAUTO, shadu=True)
        if addon.NOREPAUTO and self.fListUPD : errord(TAG_ERR_OK, TAG_ERR_OK_NEWFRC)
        
        return TAG_MNU_CANCEL  
    
        
    def mnu_chknewgl(self, updreload=False, shadow=False, shadu=False):
        self.updlock(lock=True)
        updnow(False)
        if updreload : self.sListUPD, self.fListUPD = loadTVSupd()
        resgl = self._mnu_chknewgl(updreload, shadow, shadu)
        if self.sListUPD or self.fListUPD : saveTVSupd(self.sListUPD, self.fListUPD)
        else                              : clearTVSupd() 
        
        return resgl 
        
    
    def _mnu_chknewgl(self, updreload=False, shadow=False, shadu=False):
    
        rd = TAG_MNU_CANCEL
        
        auFinish = False if (addon.AUTOUPDALL or shadu) and addon.SILENTUPD else True
    
        if not updreload : self.sListUPD, self.fListUPD = globalUpdateCheck(shadbg=shadu)
        
        while True:
        
            if not self.sListUPD and not self.fListUPD : errord(TAG_ERR_OK, TAG_ERR_OK_CHKNEW); return rd
        
            tvsNames  = [tl(TAG_MNU_SRE) + normName(itm['name']) for itm in self.fListUPD] + [normName(itm['name']) for itm in self.sListUPD] 
            tvsVals   = range(len(tvsNames))
        
            if (not addon.AUTOUPDALL and not shadu) or not addon.SILENTUPD or auFinish:
                result = subMenue(tvsNames, tvsVals, cancelVal=-1, title=titName(TAG_MNU_CHKNEWGL))
            else: 
                if self.sListUPD : result = len(self.fListUPD) 
                elif shadow : return rd
                else        : auFinish = True; continue   
            
            #if result == -1 : return TAG_MNU_BACKMAIN
            if result == -1 : return rd
            
            if result < len(self.fListUPD) : idx = result;            self.setTVS(self.fListUPD[idx]['path'], True); name = self.fListUPD[idx]['name'] 
            else                   : idx = result-len(self.fListUPD); self.setTVS(self.sListUPD[idx]['path'], True); name = self.sListUPD[idx]['name']
            
            flst = [[], []]
            for itm in self.fListUPD:
                if itm['name'] == name : flst = [itm['ups'][0], itm['ups'][1]]; break
            
            slst = [[], []]
            for itm in self.sListUPD:
                if itm['name'] == name : slst = [itm['ups'][0], itm['ups'][1]]; break
            
            lst = slst + flst 
            self.usrc = CSRC(*lst)
            del flst, slst, lst 
            
            while True:
            
                glsilent = True if (addon.AUTOUPDALL or shadu) and addon.SILENTUPD and not auFinish else False
                upres = self.mnu_chknew(globalupd=True, silent=glsilent, shadsl=shadu) 
                
                idxf = -1; idxs = -1 
                for i, itm in enumerate(self.fListUPD):   
                    if itm['name'] == name : idxf = i; break
                for i, itm in enumerate(self.sListUPD):   
                    if itm['name'] == name : idxs = i; break
                     
                try    : self.fListUPD[idxf]['ups'] = self.usrc.getfrc()
                except : pass
                try    : self.sListUPD[idxs]['ups'] = self.usrc.getsrc()   
                except : pass
                 
                if idxf > -1 and (not self.fListUPD[idxf]['ups'][0] or self.chkfull) : self.fListUPD.pop(idxf)
                if idxs > -1 and (not self.sListUPD[idxs]['ups'][0] or self.chkfull) : self.sListUPD.pop(idxs)
                
                if upres == TAG_MNU_BACKMAIN : break
                if upres == TAG_MNU_CANCEL   : 
                    if isUpdnow() : return rd
                    else          : break 
                    
            del tvsNames, tvsVals
            if not self.sListUPD and not self.fListUPD : break
            
        return rd
                   
                   
    def mnu_delete(self):                                    
        
        rd = TAG_MNU_TVSMAN
                                                              
        tvsNames, tvsPaths = getAllTVS()
        newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_MNU_DELETE))
        
        if not newPath : return rd
         
        if not confirm(TAG_MNU_DELETE, normTargetName(newPath)) : return rd
        
        self.setTVS(newPath, True)
        if not errord(deleteTVS(self.TVS), TAG_ERR_OK_DELETE, normName(self.TVS.lib_name)):
            self.linkTable.exclude(self.TVS.lib_path)
            
            self.setFile()
            self.setTVS(self.path, self.isFound)
            
            self.pageNum = 0
            self.libClean()
            self.libUpdate()  
        
        return rd 
                   
                   
    def mnu_restoreall(self):
        
        rd = TAG_MNU_TVSMAN
        
        if not confirm(TAG_MNU_RESTOREALL) : return rd
        
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
        errord(restoreAllTVS(prefix), TAG_ERR_OK_RESTOREALL)
        
        return rd
    
               
    def mnu_restore(self):   
    
        rd = TAG_MNU_TVSMAN
                 
        tvsNames, tvsPaths = getAllTVS()
        newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_MNU_RESTORE))
        
        if not newPath : return rd
         
        if not confirm(TAG_MNU_RESTORE, normTargetName(newPath)) : return rd
        
        self.setTVS(newPath, True)
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty 
        if not errord(restoreTVS(self.TVS, prefix), TAG_ERR_OK_RESTOR, normName(self.TVS.lib_name)): 
            self.libUpdate()
            return TAG_MNU_RESTORE  
        
        return rd 
                
                
    def mnu_rescanfull(self):
    
        rd = TAG_MNU_SRCMAN
        
        if not confirm(TAG_MNU_RESCANFULL) : return rd
        
        tvsNames, tvsPaths = getAllTVS()
        
        if not tvsNames : return rd
        
        self.reErrors = []
        
        progress = CProgress(len(tvsNames), bg=addon.BGUPD)
        progress.show(tla(TAG_MNU_RESCANFULL))
        
        currentPath = self.TVS.lib_path
        for path in tvsPaths:
            self.setTVS(path, True)
            progress.step(normName(self.TVS.lib_name), 1)
            self.mnu_rescanalls(full=True)    
         
        self.setTVS(currentPath, True)
        self.setLI()
        self.libUpdate()
        
        for error in self.reErrors:
            errord(error[0], Empty, error[1], exten=error[2])
            
        self.reErrors = []
        
        errord(TAG_ERR_OK, TAG_ERR_OK_RESCANFULL)
        
        return rd
    
    
    def mnu_rescanalls(self, full=False):
        
        rd = TAG_MNU_SRCMAN
        
        if not full and not confirm(TAG_MNU_RESCANALLS, normName(self.TVS.lib_name)) : return rd
        
        srccl = self.src.clone(nofrc=True)
        
        if not full : self.reErrors = []
        
        while srccl.nextsidx():
            
            self.setLI(srccl.link, srccl.name)
            src_name = srccl.name
            srccl.exclude(srccl.link)
            if srccl.link in self.TVS.get_raw_link_list() : self.mnu_rawadd(rescan=True); continue
            
            prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
            err = rescanSRC(self.items, self.TVS, prefix)
            
            if err != TAG_ERR_OK : self.reErrors.append([err, normName(self.TVS.lib_name), src_name])
        
        if not full:
            self.setLI()
            self.libUpdate()
        
            for error in self.reErrors:
                errord(error[0], Empty, error[1], exten=error[2])
                
            self.reErrors = []
            
        if not full : errord(TAG_ERR_OK, TAG_ERR_OK_RESCANALLS, normName(self.TVS.lib_name))
        
        return rd
    
    
    def mnu_rescan(self):
    
        rd = TAG_MNU_SRCMAN
                                                                  
        if not confirm(TAG_MNU_RESCAN, normName(self.TVS.lib_name), self.src.getlinkname(self.items.vidCPath)) : return rd 
        
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
        if not errord(rescanSRC(self.items, self.TVS, prefix), TAG_ERR_OK_RESCAN, normName(self.TVS.lib_name)):
            self.libUpdate()
            return TAG_MNU_CANCEL
            
        return rd
                
                
    def mnu_rawadd(self, update=False, rescan=False):
        
        rd = TAG_MNU_BACKMAIN
        
        ares = Empty
        
        if not update : resType = subMenue([TAG_MNU_MOV, TAG_MNU_TVS])
        else          : resType = TAG_MNU_TVS
        
        if   resType == TAG_MNU_MOV:
        
            self.mnu_mov(rawadd=True)
            
        elif resType == TAG_MNU_TVS:
            
            eplist = [itm[0] for itm in self.items.vidListItemsRaw]
            idxs   = range(len(eplist))
            
            if update:
                newraw = []
                tvsraw = self.TVS.get_raw_eps() 
                for idx, itm in enumerate(eplist):
                    if itm not in tvsraw : newraw.append(idx)
                
                idxsDef = newraw
                rTTL    = TAG_PAR_TTLQ % (tla(TAG_TTL_RAWADDEPS), normName(self.TVS.lib_name))
                
            else : idxsDef = idxs; rTTL = tla(TAG_TTL_RAWADDEPS)
               
            selitems = subMenue(eplist, idxs, cancelVal=-1, cancelName=TAG_MNU_OK, multiSel=True, title=rTTL,
                                selMarkm=tl(TAG_MNU_SMM), multiSelDefList=idxsDef)
            
            if not selitems : return rd
            
            self.items.setmanually(selitems)
            
            if rescan : self.TVS.os_exclude_src(self.items.vidCPath); update = True  
              
            if update : ares = self.mnu_tvsu(False)
            else      : ares = self.mnu_tvs()
            
            if ares == TAG_MNU_CANCEL:
                rawlist = [itm[0] for itm in self.items.vidListItemsRaw]
                self.TVS.os_addraw(self.items.vidCPath, rawlist)
        
        return rd
    
        
    def mnu_mov(self, rawadd=False):
        
        rd = TAG_MNU_BACKMAIN
        
        resType = subMenue([TAG_MNU_DEFNMMOV, TAG_MNU_NEWNMMOV], title=self.items.vidCurr)
        
        newName = Empty
        if   resType == TAG_MNU_BACKMAIN : return rd
        elif resType == TAG_MNU_NEWNMMOV : newName = GUI.dlgIn(tl(TAG_TTL_ENTNAMEM)) 
        
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_MOV, TAG_PAR_REPFN) if addon.CALLURL else Empty
        if not errord(addMOV(self.items, newName, prefix, rawadd), TAG_ERR_OK_MOVADD):
            self.libUpdate()
            return TAG_MNU_CANCEL
            
        return rd
               
        
    def mnu_tvs(self):
    
        rd = TAG_MNU_BACKMAIN
                                                                  
        if not self.isFound : resType = subMenue([TAG_MNU_ADDNEW, TAG_MNU_ADDEXIST, TAG_MNU_ADVADD], title=normName(self.TVS.lib_defname) if self.TVS.lib_defname else titName(TAG_TTL_ADDTVS))
        else                : resType = TAG_MNU_ADDNEW
        
        if   resType == TAG_MNU_BACKMAIN : return rd
        elif resType == TAG_MNU_ADVADD   : return self.mnu_advadd() 
        elif resType == TAG_MNU_ADDEXIST :
        
                tvsNames, tvsPaths = getAllTVS()
                newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_TTL_CHSNAME))
                
                if not newPath : return rd
                
                self.setTVS(newPath, True)
                
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty        
        errn = addTVS(self.items, self.TVS, prefix)             
        if not errord(errn, TAG_ERR_OK_TVSADD, normName(self.TVS.lib_name)):
            self.linkTable.add(self.TVS.lib_path, self.items.vidCPath)
            self.libUpdate()
            return TAG_MNU_CANCEL
        
        elif errn == TAG_ERR_NONAME : return self.mnu_advadd()
        
        return rd 
    
    
    def mnu_advadd(self):
        
        rd = TAG_MNU_BACKMAIN
        
        newtvs  = tl(TAG_MNU_NEW)   
        
        def _getParam():
        
            defname = self.TVS.lib_name if self.TVS.lib_name else createName(self.items.vidFolderNameDef)
            
            aSeason, aNumb = self.TVS.get_scr_numb_and_season(self.items.vidCPath)
            
            aSeq    = self.TVS.seq 
            aSeqT   = TAG_MNU_SEANUM if not aSeq    else TAG_MNU_SEQNUM
            aNumbT  = TAG_MNU_SERDEF if not aSeason else TAG_MNU_SERTPL
            aTVS    = normName(self.TVS.lib_name) if self.TVS.lib_name else newtvs
            aName   = defname
            
            return defname, aSeq, aSeqT, aNumb, aNumbT, aSeason, aTVS, aName
        
        defname, aSeq, aSeqT, aNumb, aNumbT, aSeason, aTVS, aName = _getParam()    
        
        result  = 0
        newPath = TAG_MNU_NEW if aTVS == newtvs else Empty
        aSortOd = TAG_MNU_ADVLSORTDOWN
        diflist = []
        cornum  = []
        skip    = 0
        
        while int(result) != -1:
        
            if not aSeason : aSeason = TAG_PAR_TVSDEFSEASON   
            aName2 = tl(TAG_MNU_DEFNM) if aName == defname else aName 
            
            mList  = []; mVals = []
            mList += [tl(TAG_MNU_ATVS) + aTVS]                   ; mVals += [0]
            
            if aTVS == newtvs :
                mList += [tl(TAG_MNU_ATVSNUMT) + tl(aSeqT)]      ; mVals += [1] 
                mList += [tl(TAG_MNU_ATVSNM)   + aName2]         ; mVals += [2]
            
            if aSeqT == TAG_MNU_SEANUM:   
                mList += [tl(TAG_MNU_ATVSSERT) + tl(aNumbT)]     ; mVals += [3]
            
            if aSeqT == TAG_MNU_SEANUM and aNumbT == TAG_MNU_SERTPL:
                mList += [tl(TAG_MNU_SEASON)   + aSeason]        ; mVals += [4]
            
            if aNumbT == TAG_MNU_SERTPL or aSeqT == TAG_MNU_SEQNUM:    
                mList += [tl(TAG_MNU_ADVLSORT) + tl(aSortOd)]    ; mVals += [5]
            
            if aNumbT == TAG_MNU_SERTPL or aSeqT == TAG_MNU_SEQNUM:
                mList += [tl(TAG_MNU_NUMBCORR)]                  ; mVals += [6]
            
            mList += [tl(TAG_MNU_EPSLISTCORR)]                   ; mVals += [7]
            
            mList += [tl(TAG_MNU_STARTADD)]                      ; mVals += [8]
        
            if not skip : result = subMenue(mList, mVals, cancelVal=-1, title=tl(TAG_TTL_ADVADD))
            else        : result = skip; skip = 0
        
            if   result == 0:
                tvsNames, tvsPaths = getAllTVS()
                tvsNames.insert(0, tl(TAG_MNU_NEW))
                tvsPaths.insert(0, TAG_MNU_NEW)
                newPath = subMenue(tvsNames, tvsPaths, cancelVal=Empty, default=DOS.unsl(self.TVS.lib_path), title=titName(TAG_TTL_CHSNAME), defidx=0)
                if newPath:
                    if newPath == TAG_MNU_NEW : self.setTVS(Empty, False)
                    else                      : self.setTVS(newPath, True)            
                    defname, aSeq, aSeqT, aNumb, aNumbT, aSeason, aTVS, aName = _getParam()
                
                
            elif result == 1: 
                aSeqT   = TAG_MNU_SEANUM if aSeqT  == TAG_MNU_SEQNUM else TAG_MNU_SEQNUM
                if cornum and (aNumbT == TAG_MNU_SERTPL or aSeqT == TAG_MNU_SEQNUM) : skip = 6
                
            elif result == 2: 
                while True  : 
                    aName = createName(GUI.dlgIn(tl(TAG_DLG_INNM), aName)) 
                    if aName : break
            
            elif result == 3: 
                aNumbT  = TAG_MNU_SERDEF if aNumbT == TAG_MNU_SERTPL else TAG_MNU_SERTPL
                if cornum and (aNumbT == TAG_MNU_SERTPL or aSeqT == TAG_MNU_SEQNUM) : skip = 6
            
            elif result == 4: 
                while True  : 
                    aSeason = GUI.dlgInnum(tl(TAG_DLG_INSE), aSeason) 
                    if aSeason : break
            
            elif result == 5: 
                aSortOd = TAG_MNU_ADVLSORTUP if aSortOd == TAG_MNU_ADVLSORTDOWN else TAG_MNU_ADVLSORTDOWN
                self.items.reverse()
                
            elif result == 6:
                eplist  = [itm[0] for itm in self.items.vidListItems]
                if not cornum : cornum = range(1, len(eplist)+1)    
        
                numList = []
                while True: 
                  
                    numList = []
                    cidx    = 0
                    for itm in eplist:
                        while True:
                            cidx += 1
                            if cidx in cornum    : break
                            if cidx > max(cornum): cornum.append(cidx); break  
                            
                            numList.append(str(cidx)+Space+Space+tl(TAG_DLG_NUMSKIP))
                            
                        numList.append(str(cidx)+Colon+Space+Space+itm)
                    
                    idxs    = range(1, len(numList)+1)
                    idxsDef = [itm for itm in range(len(numList)) if itm+1 in cornum]
                    
                    selitem = subMenue(numList, idxs, cancelVal=-1, cancelName=TAG_MNU_OK, title=tla(TAG_MNU_NUMBCORR))
                    if selitem == -1 : break
                    if selitem: 
                        if selitem in cornum: 
                            cornum.remove(selitem)
                            cornum.append(len(numList))
                        else: 
                            numList.pop(selitem-1)
                            cornum.append(selitem) 
                                                
            elif result == 7:    
                eplist    = [itm[0] for itm in self.items.vidListItemsRaw]
                seleplist = [itm[0] for itm in self.items.vidListItems]
                idxs      = range(len(eplist))
                idxsDef   = [idx for idx, itm in enumerate(eplist) if itm in seleplist]
                
                selitems = subMenue(eplist, idxs, cancelVal=-1, cancelName=TAG_MNU_OK, multiSel=True, title=normName(self.TVS.lib_name),
                                    selMarkm=tl(TAG_MNU_SMM), multiSelDefList=idxsDef)
                
                if selitems: 
                    self.items.setmanually(selitems)
                    diflistA = [itm for itm in selitems if itm not in idxsDef]  
                    diflistB = [itm for itm in idxsDef  if itm not in selitems]
                    diflist  = diflistA + diflistB  
                
                if cornum and (aNumbT == TAG_MNU_SERTPL or aSeqT == TAG_MNU_SEQNUM) : skip = 6
                
            elif result == 8: 
                if aName2 == tl(TAG_MNU_DEFNM) and newPath == TAG_MNU_NEW and not confirm(TAG_MNU_DEFNM, aName) : continue
                
                if aSeqT  == TAG_MNU_SEQNUM :
                    if aSeq < 1 : aSeq = 1 
                    self.TVS.seq = aSeq
                if aNumbT == TAG_MNU_SERDEF : aSeason = Empty 
                
                if newPath == TAG_MNU_NEW   : 
                    self.TVS.lib_name = aName
                    self.TVS.lib_path = LIB.tvs(aName)
                    
                prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
                errn = addTVS(self.items, self.TVS, prefix, aSeason, aNumb, cornum)
                
                if not errord(errn, TAG_ERR_OK_TVSADD, normName(self.TVS.lib_name)):
                    self.linkTable.add(self.TVS.lib_path, self.items.vidCPath)
                    self.libUpdate()
                    
                    if diflist:
                        rawlist = [itm[0] for itm in self.items.vidListItemsRaw]
                        self.TVS.os_addraw(self.items.vidCPath, rawlist)
                    
                    return TAG_MNU_CANCEL
                    
        return rd
                
        
    def mnu_tvsu(self, isupd=True):
    
        rd = TAG_MNU_BACKMAIN
        
        prefix = TAG_PAR_CALLURLTMPL % (addon.id, TAG_TYP_TVS, TAG_PAR_REPFN) if addon.CALLURL else Empty
        season, numb = self.TVS.get_scr_numb_and_season(self.items.vidCPath)                                   
        if not errord(addTVS(self.items, self.TVS, prefix, season, numb), TAG_ERR_OK_TVSUPD, normName(self.TVS.lib_name)):
               self.linkTable.add(self.TVS.lib_path, self.items.vidCPath)
               if isupd : self.libUpdate()
               return TAG_MNU_CANCEL
        
        return rd    
                
        
    def mnu_open(self):                                                              
        
        rd = TAG_MNU_BACKMAIN
        
        subLink  = subMenue(self.src.remnames, self.src.links, cancelVal=Empty, title=titName(TAG_MNU_OPEN, self.TVS.lib_name))
         
        if not subLink : return rd
         
        oldCont = self.items.vidCPath 
        GUI.goTarget(subLink)
        if oldCont != subLink and not isWait(oldCont, LI.getCpath, addon.LNKTIMEOUT) : errord(TAG_ERR_DEDLINK); return rd
        
        return TAG_MNU_CANCEL       
                
        
    def mnu_help(self): 
        help.showHelp()
        return TAG_MNU_BACKMAIN           
        
        
    def mnu_set(self):
        GUI.openSet()
        check_lib_folders()
        return TAG_MNU_CANCEL 
                   
    
    def mnu_vidlibu(self):                                                                            
        self.libUpdate(True, True)
        return TAG_MNU_CANCEL 
        
        
    def mnu_vidlibcln(self):                                                              
        self.libClean (True)
        self.libUpdate(False, True)
        return TAG_MNU_CANCEL
    
    
    def act_lpreset(self):
        addon.addon.setSetting('libpath', TAG_PAR_SETDEF)
        return TAG_MNU_CANCEL
        
    
    def act_chcolor(self):
        pckdcolors = DOS.file(TAG_PAR_COLORS_FILE, DOS.join(addon.path, TAG_PAR_RESFOLDER, TAG_PAR_BSFOLDER), fType=FRead)
        colors     = [color.replace(CR, Empty) for color in pckdcolors.split(NewLine)]
        colnames   = [TAG_PAR_MNUCOLORFORMAT % (color, color) for color in colors]
        defcolor   = addon.getcolor() 

        newcolor = subMenue(colnames, colors, cancelVal=Empty, default=defcolor, title=tl(TAG_TTL_COLORIZE))
        
        if newcolor : 
            addon.addon.setSetting('mnucolor', newcolor)
            addon.addon.setSetting('actcolor', newcolor)
        
        path       = DOS.join(addon.path, *TAG_PAR_STRINGSXML_PATH)
        stringsxml = DOS.file(TAG_PAR_STRINGSXML_FILE, path, fType=FRead)
        label      = CMP.comps(stringsxml)
        label.sub(TAG_PAR_ADDONLABEL_PATT, rep_text=TAG_PAR_ADDONLABEL % addon.getcolor())
        DOS.file(TAG_PAR_STRINGSXML_FILE, path, label(), fType=FWrite, fRew=True)
        
        return TAG_MNU_CANCEL
        
    
    def act_reskin(self):
        
        skins      = DOS.listdir(DOS.join(addon.path, *TAG_PAR_SKINSFOLDER))[0]
        skinsnames = [itm for itm in skins] 
        defskin    = addon.SKIN 

        skin = subMenue(skinsnames, skins, cancelVal=Empty, default=defskin, title=tl(TAG_TTL_RESKIN))
        
        if skin : 
            addon.addon.setSetting('skin', skin)
            addon.addon.setSetting('actskin', skin)
        
        return TAG_MNU_CANCEL
    
    
    def act_renamer(self):
        rd = TAG_MNU_CANCEL
        if not confirm(TAG_ACT_RENAMER) : return rd
        srcRenamer()
        errord(TAG_ERR_OK, TAG_ERR_OK_RENAMER)
        return rd
        
        
    def act_resettbu(self):
        addon.addon.setSetting('bkuppath', TAG_PAR_SETDEF)
        return TAG_MNU_CANCEL
        
    
    def act_autobackup(self):    
        return self.act_backup(True)
        
    
    def act_backup(self, auto=False):
        rd = TAG_MNU_CANCEL
        
        self.updlock(lock=True)
        
        errord(backup(auto), TAG_ERR_OK_BACKUP)
        
        return rd
    
    
    def act_remback(self):
        rd = TAG_MNU_CANCEL
        
        if not confirm(TAG_ACT_REMBACK) : return rd
        errord(remove_all_backups(), TAG_ERR_OK_REMBACK)
        
        return rd
    
    
    def act_restback(self):
        rd = TAG_MNU_CANCEL
        
        self.updlock(lock=True)
        
        backups = get_all_sort_backups()
        if backups == -1:
            errord(TAG_ERR_NOBCKPATH, Empty) 
            return rd
            
        if not backups:
            errord(TAG_ERR_OK, TAG_ERR_OK_NOBACK) 
            return rd
        
        bcknames = []
        for name in backups:
            pn = parse_backupname(name)
            bcknames.append(tl(TAG_TTL_BCKNM) % (pn[2], pn[1], pn[0], pn[3], pn[4], pn[5], pn[6]))
        
        bckname = subMenue(bcknames, backups, cancelVal=Empty, default=backups[0], title=tl(TAG_TTL_RESTBACK))
         
        if not bckname or not confirm(TAG_ACT_RESTBACK, srcName=bckname) : return rd
        
        if not errord(restore_lib(bckname), TAG_ERR_OK_RESTBACK):
            self.libClean()
            self.libUpdate()
            
        return rd
        
    
    def act_donothing(self):
        return TAG_MNU_CANCEL


##### Start main ...
if __name__ == '__main__':  Main()